#include "StdAfx.h"
#include "ZSDVideoPlayer.h"
#include "ZSDVideoPlayerApp.h"
#include <vector>
#include <map>


int __voxVideoPlayerCount = 0;
HVIDEOOBJ __hVideoObject = NULL;

typedef std::map<std::string, bool> UriLoginMap;
UriLoginMap __hostLoginMap;




ZSDVideoPlayer::ZSDVideoPlayer(const std::wstring& uri, const std::string& videoId, bool bShowWindow)
: m_uri(uri)
, m_videoId(videoId)
, m_bShowWindow(bShowWindow)
{
	++ __voxVideoPlayerCount;		
}

ZSDVideoPlayer::~ZSDVideoPlayer()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	m_dlg.StopPlay();
	m_dlg.DestroyWindow();


	-- __voxVideoPlayerCount;
	if(__voxVideoPlayerCount == 0)
	{
		IRV_Logout(__hVideoObject);
		IRV_DestroyVideoObject(__hVideoObject);
		__hVideoObject = NULL;
	}
}


void ZSDVideoPlayer::SetRenderSampleCallback(const RenderSampleCallback& cb)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());
    m_dlg.SetParam(m_uri, m_videoId, cb);
    m_dlg.Create(CVideoPlayDlg::IDD);
	m_dlg.ShowWindow(m_bShowWindow?SW_SHOW:SW_HIDE);
    m_dlg.UpdateWindow();
}

bool ZSDVideoPlayer::Run()
{
    return false;
}


bool ZSDVideoPlayer::Stop()
{
    return false;
}


bool ZSDVideoPlayer::Pause()
{
    return false;
}


bool ZSDVideoPlayer::IsRunning()
{
    return false;
}


bool ZSDVideoPlayer::IsStopped()
{
    return false;
}


bool ZSDVideoPlayer::IsPaused()
{
    return false;
}


bool ZSDVideoPlayer::IsComplete()
{
    return false;
}



bool ZSDVideoPlayer::GetCurrentPosition(double * dRet)
{
    *dRet = 0;
    return false;
}


bool ZSDVideoPlayer::GetStopPosition(double * dRet)
{
    return false;
}


bool ZSDVideoPlayer::SetCurrentPosition(double inPosition)
{

    return false;
}


bool ZSDVideoPlayer::SetStartStopPosition(double inStart, double inStop)
{
    return false;
}


bool ZSDVideoPlayer::GetDuration(double * dRet)
{
    *dRet = 1;
    return false;
}


bool ZSDVideoPlayer::SetPlaybackRate(double inRate)
{
    return false;
}


void Tokenize(const std::string& str,  
              std::vector<std::string>& tokens,  
              const std::string& delimiters)  
{  
    tokens.clear();
    // Skip delimiters at beginning.  
    std::string::size_type lastPos = str.find_first_not_of(delimiters, 0);  
    // Find first "non-delimiter".  
    std::string::size_type pos     = str.find_first_of(delimiters, lastPos);  
    while (std::string::npos != pos || std::string::npos != lastPos)  
    {  
        // Found a token, add it to the vector.  
        tokens.push_back(str.substr(lastPos, pos - lastPos));  
        // Skip delimiters.  Note the "not_of"  
        lastPos = str.find_first_not_of(delimiters, pos);  
        // Find next "non-delimiter"  
        pos = str.find_first_of(delimiters, lastPos);  
    }  
}  



bool ZSDInit()
{
	if(__hVideoObject != NULL)
		return true;

	TCHAR szPath[MAX_PATH];
	GetModuleFileName(NULL, szPath, MAX_PATH);
	CString strPath(szPath);
	strPath = strPath.Left(strPath.ReverseFind('\\') + 1);
	SetCurrentDirectory(strPath);
 
	if(NULL != __hVideoObject)
	{
		IRV_DestroyVideoObject(__hVideoObject);
		__hVideoObject = NULL;
	}
	__hVideoObject = IRV_CreateVideoObject(405);
	if(NULL == __hVideoObject)
		return false;

	return true;
}


/************************************************************************/
/* �ַ�����ʽ��
    vp://zsdv/119.139.199.53:12121:01-0-3/admin/admin/1
/************************************************************************/
extern "C" VIDEOPLAYER_API IVideoPlayer* VideoPlayerDllStartup(const std::wstring& uri)
{
    USES_CONVERSION;
    AFX_MANAGE_STATE(AfxGetStaticModuleState());
    IVideoPlayer* r = NULL;

	bool isValidURI = false;
	std::string strIP;
	int nPort;
	std::string videoId;
	std::string strUser;
	std::string strPass;
	bool bShowWindow = false;

	std::string auri = W2A(uri.c_str());
	int n = auri.find("vp://zsdv/");
	if(n != -1)
	{
		std::string ss = auri.substr(10);

		std::vector<std::string> vs;
		Tokenize(ss, vs, "/");

		if(vs.size() >= 3)
		{
			std::string strHost = vs[0];
			strUser = vs[1];
			strPass = vs[2];
			if(vs.size() == 4)
				bShowWindow = !!atoi(vs[3].c_str());

			Tokenize(strHost, vs, ":");
			if(vs.size() >= 3)
			{
				strIP = vs[0];
				nPort = atoi(vs[1].c_str());
				videoId = vs[2].c_str();
				isValidURI = true;
			}
		}
	}

	if(isValidURI)
	{
		if(__hVideoObject == NULL)
			ZSDInit();

		char buffHost[100];
		sprintf(buffHost, "%s:%d", strIP.c_str(), nPort);
		bool hasLogin = __hostLoginMap[buffHost];
		if(!hasLogin)
		{
			INT nRet = IRV_Login(__hVideoObject, strIP.c_str(), nPort, strUser.c_str(), strPass.c_str());
			if(nRet == IRV_ERROR_OK)
			{		
				__hostLoginMap[buffHost] = true;
				r = new ZSDVideoPlayer(uri, videoId, bShowWindow);
			}
		}	
		else
		{
			r = new ZSDVideoPlayer(uri, videoId, bShowWindow);
		}
	}

    return r;
}


