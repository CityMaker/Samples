#pragma once
#include "VideoPlayer/IVideoPlayer.h"
#include "VideoPlayDlg.h"
#include "IRVideoDispatchDll.h"


class ZSDVideoPlayer : public IVideoPlayer
{
public:
    ZSDVideoPlayer(const std::wstring& uri, const std::string& videoId, bool bShowWindow);
    ~ZSDVideoPlayer();

    virtual void SetRenderSampleCallback(const RenderSampleCallback& cb); 

    virtual bool Run();
    virtual bool Stop();
    virtual bool Pause();
    virtual bool IsRunning(); 
    virtual bool IsStopped();
    virtual bool IsPaused();
    virtual bool IsComplete();

    virtual bool GetCurrentPosition(double * dRet);
    virtual bool GetStopPosition(double * dRet);
    virtual bool SetCurrentPosition(double inPosition);
    virtual bool SetStartStopPosition(double inStart, double inStop);
    virtual bool GetDuration(double * dRet);
    virtual bool SetPlaybackRate(double inRate);
 

private:
    std::wstring m_uri;
    std::string m_videoId;
    CVideoPlayDlg m_dlg;
	bool m_bShowWindow;

private:
};