#pragma once
#include <string>
#include "FastDelegate.h"
#include "Referenced.h"


#ifdef VIDEOPLAYER_EXPORTS
#define VIDEOPLAYER_API __declspec(dllexport)
#else
#define VIDEOPLAYER_API __declspec(dllimport)
#endif

typedef vp::FastDelegate3<unsigned char*, int, int> RenderSampleCallback;

class IVideoPlayer : public vp::Referenced
{
public:
    virtual void SetRenderSampleCallback(const RenderSampleCallback& cb) = 0; 

    virtual bool Run() = 0;
    virtual bool Stop() = 0;
    virtual bool Pause() = 0;
    virtual bool IsRunning() = 0; 
    virtual bool IsStopped() = 0;
    virtual bool IsPaused() = 0;
    virtual bool IsComplete() = 0;

    virtual bool GetCurrentPosition(double * dRet) = 0;
    virtual bool GetStopPosition(double * dRet) = 0;
    virtual bool SetCurrentPosition(double inPosition) = 0;
    virtual bool SetStartStopPosition(double inStart, double inStop) = 0;
    virtual bool GetDuration(double * dRet) = 0;
    virtual bool SetPlaybackRate(double inRate) = 0;
};


extern "C" VIDEOPLAYER_API IVideoPlayer* VideoPlayerDllStartup(const std::wstring& uri);

