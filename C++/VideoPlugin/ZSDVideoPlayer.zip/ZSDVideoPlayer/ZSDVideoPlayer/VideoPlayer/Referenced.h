#ifndef __VP_REFERENCED_INC_H__
#define __VP_REFERENCED_INC_H__


namespace vp
{
class Referenced
{
public:
    Referenced()
        : _ref_count(0)
    {}

    virtual ~Referenced(){}

    void Ref() const
    {
        ++_ref_count;
    }

    void Unref() const
    {
        if (0 == --_ref_count)
            Dispose();
    }

	void Unref_nodelete() const
	{
		--_ref_count;
	}

    int Ref_count() const
    {
        return _ref_count;
    }

protected:
    Referenced& operator=(const Referenced&)
    {    // �޲���
        return *this;
    }
	
	virtual void Dispose() const
	{
		delete this;
	}

	//�������FastObjectPool����ع����Ļ���Ҫʵ��Reset����
	virtual void Reset(){}

    // ��ֹ���ƹ��캯��
    Referenced(const Referenced&){}

private:
	mutable int _ref_count;
};


} 

#endif  // __VP_REFERENCED_INC_H__
