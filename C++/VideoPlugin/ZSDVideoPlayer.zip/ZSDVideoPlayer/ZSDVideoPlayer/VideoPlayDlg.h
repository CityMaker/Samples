#pragma once
#include "resource.h"
#include "YuvTool.h"
#include "IRVideoDispatchDll.h"


// CVideoPlayDlg �Ի���

class CVideoPlayDlg : public CDialog
{
    DECLARE_DYNAMIC(CVideoPlayDlg)
    DECLARE_MESSAGE_MAP()

public:
    CVideoPlayDlg(CWnd* pParent = NULL);   // ��׼���캯��
    virtual ~CVideoPlayDlg();

    // �Ի�������
    enum { IDD = IDD_DIALOG_VIDEO };
	unsigned char* m_bmpBuffer;
	RenderSampleCallback m_callback;

    //YUV����
	static  int WINAPI  OnFrameProcCB(LPIRV_FRAME_DATA pFramedata,VOID *pUser);//��Ƶ����ص�

	void StopPlay();

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
    virtual BOOL OnInitDialog();

private:
    std::string m_videoId;   
    std::wstring m_uri;
	bool m_bStopped;
    HVIDEOSTREAM m_hVideoStream;
	HANDLE m_hFrameEvent;


public:
    void SetParam(const std::wstring& uri, const std::string& videoId, const RenderSampleCallback& cb);
	afx_msg void OnDestroy();
};
