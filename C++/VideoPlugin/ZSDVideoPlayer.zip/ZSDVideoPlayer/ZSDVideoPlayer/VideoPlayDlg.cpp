// VideoPlayDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ZSDVideoPlayer.h"
#include "ZSDVideoPlayerApp.h"
#include "VideoPlayDlg.h"


YuvTool yuvTool;
extern long __voxInstance;
extern HVIDEOOBJ __hVideoObject;



// CVideoPlayDlg �Ի���

IMPLEMENT_DYNAMIC(CVideoPlayDlg, CDialog) 

CVideoPlayDlg::CVideoPlayDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVideoPlayDlg::IDD, pParent)
	, m_bmpBuffer(NULL)
	, m_hVideoStream(NULL)
	, m_bStopped(false)
	, m_hFrameEvent(NULL)
{
}

CVideoPlayDlg::~CVideoPlayDlg()
{
	if(m_bmpBuffer)
	{
		delete m_bmpBuffer;
		m_bmpBuffer = NULL;
	}

}

void CVideoPlayDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CVideoPlayDlg, CDialog)
	ON_WM_DESTROY()
END_MESSAGE_MAP()


// CVideoPlayDlg ��Ϣ��������

BOOL CVideoPlayDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    SetWindowText(m_uri.c_str());

	USES_CONVERSION;
	if(NULL == m_hVideoStream)
	{
		m_hVideoStream = IRV_CreateVideoStream(__hVideoObject);
	}
	if(NULL == m_hVideoStream)
	{
		MessageBox(L"������Ƶ��ʧ��!", NULL, MB_OK | MB_ICONWARNING);
		return IRV_ERROR_Malloc;
	}


	IRV_VideoStream_Param vsParam;
	memset(&vsParam,0x00,sizeof(vsParam));
	strncpy_s(vsParam.szChnlName, m_videoId.c_str() ,sizeof(vsParam.szChnlName) - 1);
	vsParam.ePlayMode = IRV_PM_Live;
	vsParam.nChannel = 0;
	vsParam.nStreamType = 0;
	vsParam.nCodecType = 0;

	int m_nReqWidth = 704;
	int m_nReqHeight = 480;
	IRV_SetVideoStreamOption(m_hVideoStream,IRV_OPTN_Width,(BYTE*)&m_nReqWidth,sizeof(m_nReqWidth));
	IRV_SetVideoStreamOption(m_hVideoStream,IRV_OPTN_Height,(BYTE*)&m_nReqHeight,sizeof(m_nReqHeight));
	IRV_SetVideoStreamOnDec(m_hVideoStream,OnFrameProcCB,this);

	//ʵʱ
	int nRet = IRV_OpenVideoStream(m_hVideoStream,&vsParam, m_hWnd, NULL);
	if(nRet != IRV_ERROR_OK)
	{
		CString strMsg;
		strMsg.Format(L"����Ƶͨ��ʧ��,����ֵΪ:%d",nRet);
		MessageBox(strMsg,NULL,MB_OK | MB_ICONWARNING);
		IRV_DestroyVideoStream(m_hVideoStream);

		return TRUE;
	}


    return TRUE; 
}


void CVideoPlayDlg::SetParam(const std::wstring& uri, const std::string& videoId, const RenderSampleCallback& cb)
{
	m_hFrameEvent = CreateEvent(NULL, TRUE, TRUE,  uri.c_str());

    m_uri = uri;
    m_videoId = videoId;
    m_callback = cb;
}


//��Ƶ����ص�
int WINAPI CVideoPlayDlg::OnFrameProcCB(LPIRV_FRAME_DATA pFramedata,VOID *pUser)
{
	CVideoPlayDlg * pThis = (CVideoPlayDlg*)pUser;
	if(pThis->m_bStopped)
	{
		SetEvent(pThis->m_hFrameEvent);
		return 0;
	}

	ResetEvent(pThis->m_hFrameEvent);

	if(pThis->m_bmpBuffer == NULL)
	{
		pThis->m_bmpBuffer=new unsigned char[pFramedata->width*pFramedata->height*3];
	}
	yuvTool.ConvertYUVtoRGB(pFramedata->data[0], pFramedata->data[1], pFramedata->data[2], pThis->m_bmpBuffer, pFramedata->width, pFramedata->height);

	if(pThis->m_bStopped)
	{
		SetEvent(pThis->m_hFrameEvent);
		return 0;
	}

	pThis->m_callback(pThis->m_bmpBuffer, pFramedata->width, pFramedata->height);

	SetEvent(pThis->m_hFrameEvent);
	return 0;
}

 

void CVideoPlayDlg::OnDestroy()
{
	CDialog::OnDestroy();
}


void CVideoPlayDlg::StopPlay()
{
	m_bStopped = true;
	WaitForSingleObject(m_hFrameEvent, INFINITE);
	if(m_hVideoStream != NULL)
	{
		IRV_CloseVideoStream(m_hVideoStream);
		IRV_DestroyVideoStream(m_hVideoStream);
		m_hVideoStream = NULL;
	}
}