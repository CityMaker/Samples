﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TerrainVideo
{
    public class CommonUnity
    {
        public static Gvitech.CityMaker.Controls.AxRenderControl RenderHelper;
    }
}
