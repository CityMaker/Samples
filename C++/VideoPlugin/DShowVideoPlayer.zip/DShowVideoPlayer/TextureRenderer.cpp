#include "stdafx.h"
#include "DXGraph.h"
#include "TextureRenderer.h"
#include "IVideoPlayer.h"
#include <atlimage.h>


//����ڴ�й©
#ifdef	_DEBUG
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#define new new( _CLIENT_BLOCK, __FILE__, __LINE__)
#endif


//-----------------------------------------------------------------------------
// CTextureRenderer constructor
//-----------------------------------------------------------------------------
CTextureRenderer::CTextureRenderer( LPUNKNOWN pUnk, HRESULT *phr )
	: CBaseVideoRenderer(__uuidof(CLSID_TextureRenderer), 
					 NAME("Texture Renderer"), pUnk, phr)
					 
{
	// Store and AddRef the texture for our use.
	ASSERT(phr);
	if (phr)
		*phr = S_OK;
}


//-----------------------------------------------------------------------------
// CTextureRenderer destructor
//-----------------------------------------------------------------------------
CTextureRenderer::~CTextureRenderer()
{
	// Do nothing
}


//-----------------------------------------------------------------------------
// CheckMediaType: This method forces the graph to give us an R8G8B8 video
// type, making our copy to texture memory trivial.
//-----------------------------------------------------------------------------
HRESULT CTextureRenderer::CheckMediaType(const CMediaType *pmt)
{
	HRESULT   hr = E_FAIL;
	VIDEOINFO *pvi=0;

	CheckPointer(pmt,E_POINTER);

	//////////////////////////////////////////////////////////////////////////
	const GUID* t1 = pmt->Type();
	const GUID* t2 = pmt->Subtype();
	const GUID* t3 = pmt->FormatType();
	//////////////////////////////////////////////////////////////////////////

	// Reject the connection if this is not a video type
	if( *pmt->FormatType() != FORMAT_VideoInfo ) {
		return E_INVALIDARG;
	}

	// Only accept RGB24 video
	pvi = (VIDEOINFO *)pmt->Format();

	if(IsEqualGUID( *pmt->Type(),    MEDIATYPE_Video)  &&
		IsEqualGUID( *pmt->Subtype(), MEDIASUBTYPE_RGB24))
	{
		hr = S_OK;
	}

	return hr;
}


//-----------------------------------------------------------------------------
// SetMediaType: Graph connection has been made. 
//-----------------------------------------------------------------------------
HRESULT CTextureRenderer::SetMediaType(const CMediaType *pmt)
{
	// Retrive the size of this media type
	VIDEOINFO *pviBmp;                      // Bitmap info header
	pviBmp = (VIDEOINFO *)pmt->Format();

	m_lVidWidth  = pviBmp->bmiHeader.biWidth;
	m_lVidHeight = abs(pviBmp->bmiHeader.biHeight);
	m_lVidPitch  = (m_lVidWidth * 3 + 3) & ~(3); // We are forcing RGB24


	return S_OK;
} 


//-----------------------------------------------------------------------------
// DoRenderSample: A sample has been delivered. Copy it to the texture.
//-----------------------------------------------------------------------------
HRESULT CTextureRenderer::DoRenderSample( IMediaSample * pSample )
{
	if(m_callback && pSample)
    {
        // Get the video bitmap buffer
        BYTE  *pBmpBuffer = NULL;
        HRESULT hr = pSample->GetPointer( &pBmpBuffer );
        if(SUCCEEDED(hr) && pBmpBuffer)

		m_callback(pBmpBuffer, m_lVidWidth, m_lVidHeight);
    }

	return S_OK;
}


void CTextureRenderer::SetCallback(const RenderSampleCallback& cb)
{
	m_callback = cb;
}





