#pragma once
#pragma warning(disable: 4995 4251 4312 4311)
#include <DShow.h>


class CDXGraph
{
public:
	CDXGraph();
	virtual ~CDXGraph();

public:
	HRESULT CreateFilterGraph();
	HRESULT OpenVideoFile(LPCTSTR lpszFilePath, const RenderSampleCallback& cb);
	void Release();

	BOOL Run();  // Control filter graph
	BOOL Stop();
	BOOL Pause();
	BOOL IsRunning(); // Filter graph status
	BOOL IsStopped();
	BOOL IsPaused();
	BOOL IsComplete();

	// IMediaSeeking
	BOOL GetCurrentPosition(double * dRet) const;
	BOOL GetStopPosition(double * dRet) const;
	BOOL SetCurrentPosition(double inPosition);
	BOOL SetStartStopPosition(double inStart, double inStop);
	BOOL GetDuration(double * dRet) const;
	BOOL SetPlaybackRate(double inRate);

	// Attention: range from -10000 to 0, and 0 is FULL_VOLUME.
	BOOL SetAudioVolume(long inVolume);
	long GetAudioVolume() const;
	// Attention: range from -10000(left) to 10000(right), and 0 is both.
	BOOL SetAudioBalance(long inBalance);
	long GetAudioBalance() const;
	void SetLanguage(HWND hWndParent, unsigned char ls);
	
private:
	void Msg(TCHAR *szFormat, ...);

private:
	IGraphBuilder*  m_pGraphBuilder; 
	IMediaControl* m_pMediaControl;
	IMediaEventEx* m_pMediaEventEx;
	IBasicAudio* m_pBasicAudio;
	IMediaSeeking* m_pMediaSeeking;
	DWORD m_dwObjectTableEntry; 
	//GvLog::Logger logger;
	//unsigned char m_language;
	HWND m_hWndParent;    
};
