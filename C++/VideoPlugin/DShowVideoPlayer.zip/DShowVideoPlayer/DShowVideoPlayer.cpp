// VideoPlayer.cpp : ���� DLL Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "DShowVideoPlayer.h"
#include "DXGraph.h"
#include <atlstr.h>


bool APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}



DShowVideoPlayer::DShowVideoPlayer(const std::wstring& uri)
    : m_strURI(uri)
{
    
}


DShowVideoPlayer::~DShowVideoPlayer()
{
    //ChengHongxiu 2014.09.25 ����ڴ�й©����!!!!!
    if(m_pDxGraph)
    {
        if(IsRunning())
            Stop();

        delete m_pDxGraph;
        m_pDxGraph = NULL;
    }
}

void DShowVideoPlayer::SetRenderSampleCallback(const RenderSampleCallback& cb)
{
    m_callback = cb;

    if(!m_strURI.empty())
    {
        m_pDxGraph = new CDXGraph();
        m_pDxGraph->OpenVideoFile(m_strURI.c_str(), m_callback);        
    }
}


bool DShowVideoPlayer::Run()
{
    if(m_pDxGraph)
        return !!((CDXGraph*)m_pDxGraph)->Run();
    return false;
}

bool DShowVideoPlayer::Stop()
{
    if(m_pDxGraph)
        return !!((CDXGraph*)m_pDxGraph)->Stop();
    return false;
}

bool DShowVideoPlayer::Pause()
{
    if(m_pDxGraph)
        return !!((CDXGraph*)m_pDxGraph)->Pause();
    return false;
}

bool DShowVideoPlayer::IsRunning()
{
    if(m_pDxGraph)
        return !!((CDXGraph*)m_pDxGraph)->IsRunning();
    return false;
}

bool DShowVideoPlayer::IsStopped()
{
    if(m_pDxGraph)
        return !!((CDXGraph*)m_pDxGraph)->IsStopped();
    return false;
}

bool DShowVideoPlayer::IsPaused()
{
    if(m_pDxGraph)
        return !!((CDXGraph*)m_pDxGraph)->IsPaused();
    return false;
}

bool DShowVideoPlayer::IsComplete()
{
    if(m_pDxGraph)
        return !!((CDXGraph*)m_pDxGraph)->IsComplete();
    return false;
}

bool DShowVideoPlayer::GetCurrentPosition(double * dRet)
{
    if(m_pDxGraph)
        return !!((CDXGraph*)m_pDxGraph)->GetCurrentPosition(dRet);
    return false;
}

bool DShowVideoPlayer::GetStopPosition(double * dRet) 
{
    if(m_pDxGraph)
        return !!((CDXGraph*)m_pDxGraph)->Pause();
    return false;
}

bool DShowVideoPlayer::SetCurrentPosition(double inPosition)
{
    if(m_pDxGraph)
        return !!((CDXGraph*)m_pDxGraph)->SetCurrentPosition(inPosition);
    return false;
}

bool DShowVideoPlayer::SetStartStopPosition(double inStart, double inStop)
{
    if(m_pDxGraph)
        return !!((CDXGraph*)m_pDxGraph)->SetStartStopPosition(inStart, inStop);
    return false;
}

bool DShowVideoPlayer::GetDuration(double * dRet) 
{
    if(m_pDxGraph)
        return !!((CDXGraph*)m_pDxGraph)->GetDuration(dRet);
    return false;
}

bool DShowVideoPlayer::SetPlaybackRate(double inRate)
{
    if(m_pDxGraph)
        return !!((CDXGraph*)m_pDxGraph)->SetPlaybackRate(inRate);
    return false;
}


//////////////////////////////////////////////////////////////////////////

extern "C" VIDEOPLAYER_API IVideoPlayer* VideoPlayerDllStartup(const std::wstring& uri)
{
    IVideoPlayer* r = NULL;

    std::wstring s = uri.substr(uri.length() - 4);
    std::transform(s.begin(), s.end(), s.begin(), ::tolower);

    bool valid = (s == L".avi") 
        || (s == L".mp4")
        || (s == L".flv")
        || (s == L".3gp")
        || (s == L".mpg")
        || (s == L".mov")
        || (s == L".wmv")
        ;

    if(valid)
    {
        r = new DShowVideoPlayer(uri);
    }

    return r;
}


