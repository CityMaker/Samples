#include "stdafx.h"
#include "DXGraph.h"
#include "TextureRenderer.h"
#include <stdio.h>


//����ڴ�й©
#ifdef	_DEBUG
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#define new new( _CLIENT_BLOCK, __FILE__, __LINE__)
#endif

#define SAFE_RELEASE(p) if(p){ p->Release(); p = NULL;}

////////////////////////////////////////////////////////////////////////////////
CDXGraph::CDXGraph()
    : m_hWndParent(NULL)
{
	::CoInitialize(NULL);
	m_pGraphBuilder = NULL; 
	m_pMediaControl = NULL;
	m_pMediaEventEx = NULL;
	m_pBasicAudio = NULL;
	m_pMediaSeeking = NULL;

	m_dwObjectTableEntry = 0; 

	//logger.init(MODULE_VIDEOPLAYER, _T("DXGraph"));
	//logger.outline(L"======================================");
	//logger.outdate();
	//logger.outline(L"======================================");
}

CDXGraph::~CDXGraph()
{ 
	Release();
}

void CDXGraph::Release()
{
	SAFE_RELEASE(m_pMediaSeeking);
	SAFE_RELEASE(m_pMediaControl);
	SAFE_RELEASE(m_pMediaEventEx);
	SAFE_RELEASE(m_pBasicAudio);
	SAFE_RELEASE(m_pGraphBuilder);
	//::CoUninitialize();
}

void CDXGraph::SetLanguage(HWND hWndParent, unsigned char ls)
{
	m_hWndParent = hWndParent;
}

HRESULT CDXGraph::CreateFilterGraph()
{
	if(m_pGraphBuilder)
		return S_OK;

	HRESULT hr = CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, IID_IGraphBuilder, (void **)&m_pGraphBuilder);
	if (SUCCEEDED(hr))
	{
		HRESULT hr = NOERROR;
		hr |= m_pGraphBuilder->QueryInterface(IID_IMediaControl, (void **)&m_pMediaControl);
		hr |= m_pGraphBuilder->QueryInterface(IID_IMediaEventEx, (void **)&m_pMediaEventEx);
		hr |= m_pGraphBuilder->QueryInterface(IID_IBasicAudio, (void **)&m_pBasicAudio);
		hr |= m_pGraphBuilder->QueryInterface(IID_IMediaSeeking, (void **)&m_pMediaSeeking);
		if (m_pMediaSeeking)
			m_pMediaSeeking->SetTimeFormat(&TIME_FORMAT_MEDIA_TIME);
	}
	else
	{
		//logger.error(L"CLSID_FilterGraph CoCreateInstance Failed! HRESULT: %d", hr);
	}

	return hr;  
}

HRESULT CDXGraph::OpenVideoFile(LPCTSTR lpszFilePath, const RenderSampleCallback& cb)
{
	//logger.info(L"File: %s", lpszFilePath);

	HRESULT hr = S_OK;
	if(!m_pGraphBuilder)
	{
		hr = CreateFilterGraph();
		if(FAILED(hr))
			return hr;
	}

	/*if(bShowWindow)
	{
		hr = m_pGraphBuilder->RenderFile(lpszFilePath, NULL);
		if(FAILED(hr))
			goto Faild;
	}
	else*/
	{
		CComPtr<IBaseFilter> pTextureRenderFilter;		// Texture Renderer Filter
		CComPtr<IBaseFilter> pSourceFilter;				// Source Filter
		CComPtr<IPin>  pSourceFilterPinOut;				// Source Filter Output Pin 
		CTextureRenderer *pCTextureRenderFilter = NULL;	// DirectShow Texture renderer

		// Create the Texture Renderer object
		pCTextureRenderFilter = new CTextureRenderer(NULL, &hr);
		if (FAILED(hr) || !pCTextureRenderFilter)
		{
			//logger.error(TEXT("Could not create texture renderer object!  hr=0x%x"), hr);
			goto Faild;
			return E_FAIL;
		}
		pCTextureRenderFilter->SetCallback(cb);

		// Get a pointer to the IBaseFilter on the TextureRenderer, add it to graph
		pTextureRenderFilter = pCTextureRenderFilter;
		if (FAILED(hr = m_pGraphBuilder->AddFilter(pTextureRenderFilter, L"TEXTURERENDERER")))
		{
			//logger.error(TEXT("Could not add renderer filter to graph!  hr=0x%x"), hr);
			goto Faild;
			return hr;
		}

		// Add the source filter to the graph.
		hr = m_pGraphBuilder->AddSourceFilter (lpszFilePath, L"SOURCE", &pSourceFilter);

		// If the media file was not found, inform the user.
		if (hr == VFW_E_NOT_FOUND)
		{
			//logger.error(TEXT("Could not add source filter to graph!  (hr==VFW_E_NOT_FOUND)\r\n\r\n")
				//TEXT("This sample reads a media file from the DirectX SDK's media path.\r\n")
				//TEXT("Please install the DirectX 9 SDK on this machine."));
			goto Faild;
			return hr;
		}
		else if(FAILED(hr))
		{
			//logger.error(TEXT("Could not add source filter to graph!  hr=0x%x"), hr);
			goto Faild;
			return hr;
		}

		if (FAILED(hr = pSourceFilter->FindPin(L"Output", &pSourceFilterPinOut)))
		{
			//logger.error(TEXT("Could not find output pin!  hr=0x%x"), hr);
			goto Faild;
			return hr;
		}

		// Render the source filter's output pin. The Filter Graph Manager
		// will connect the video stream to the loaded CTextureRenderer
		// and will load and connect an audio renderer (if needed).
		if (FAILED(hr = m_pGraphBuilder->Render(pSourceFilterPinOut)))
		{
			//logger.error(TEXT("Could not render source output pin!  hr=0x%x"), hr);
			goto Faild;
			return hr;
		}
	}

	// Start the graph running;
	if (FAILED(hr = m_pMediaControl->Run()))
	{
		//logger.error(TEXT("Could not run the DirectShow graph!  hr=0x%x"), hr);
		goto Faild;
		return hr;
	}

	return S_OK;

Faild:
	//if(m_language == ChineseSimple)
	//	MessageBox(m_hWndParent, _T("�޷�����ָ������Ƶ�ļ����Ҳ�����Ӧ�Ľ�������"), _T("����"), MB_OK|MB_ICONSTOP);
	//else if(m_language == ChineseTraditional)
	//	MessageBox(m_hWndParent, _T("�o������ָ����ҕ�l�ļ����Ҳ��������Ľ�a����"), _T("�e�`"), MB_OK|MB_ICONSTOP);
	//else
	//	MessageBox(m_hWndParent, _T("Can not play the specified video without matched decoder."), _T("ERROR"), MB_OK|MB_ICONSTOP);

	return hr;
}




BOOL CDXGraph::Run()
{
	if(!m_pGraphBuilder || !m_pMediaControl)
		return FALSE;

	if(IsRunning())
		return TRUE;

	if (SUCCEEDED(m_pMediaControl->Run()))
		return TRUE;
	else
		return FALSE;
}

BOOL CDXGraph::Stop()
{
	if(!m_pGraphBuilder || !m_pMediaControl)
		return FALSE;

	if(IsStopped())
		return TRUE;

	if (SUCCEEDED(m_pMediaControl->Stop()))
		return TRUE;
	else
		return FALSE;

}

BOOL CDXGraph::Pause()
{
	if(!m_pGraphBuilder || !m_pMediaControl)
		return FALSE;

	if(IsPaused())
		return TRUE;

	if (SUCCEEDED(m_pMediaControl->Pause()))
		return TRUE;
	else
		return FALSE;
}

BOOL CDXGraph::IsRunning()
{
	if(!m_pGraphBuilder || !m_pMediaControl)
		return FALSE;
	
	OAFilterState state = State_Stopped;
	if (SUCCEEDED(m_pMediaControl->GetState(10, &state)))
		return state == State_Running;

	return FALSE;
}

BOOL CDXGraph::IsStopped()
{
	if(!m_pGraphBuilder || !m_pMediaControl)
		return FALSE;

	OAFilterState state = State_Stopped;
	if (SUCCEEDED(m_pMediaControl->GetState(10, &state)))
		return state == State_Stopped;
	
	return FALSE;
}

BOOL CDXGraph::IsPaused()
{
	if(!m_pGraphBuilder || !m_pMediaControl)
		return FALSE;

	OAFilterState state = State_Stopped;
	if (SUCCEEDED(m_pMediaControl->GetState(10, &state)))
		return state == State_Paused;

	return FALSE;
}

BOOL CDXGraph::IsComplete()
{
	long lEventCode;
	static long lParam1;
	static long lParam2;
	HRESULT hr;
	BOOL bRet = FALSE;

	if (!m_pMediaEventEx)
		return bRet;

	// Check for completion events
	hr = m_pMediaEventEx->GetEvent(&lEventCode, (LONG_PTR *) &lParam1, (LONG_PTR *) &lParam2, 0);
	if (SUCCEEDED(hr))
	{
		// If we have reached the end of the media file, reset to beginning
		if(EC_COMPLETE == lEventCode)
			bRet = TRUE;

		// Free any memory associated with this event
		hr = m_pMediaEventEx->FreeEventParams(lEventCode, lParam1, lParam2);
	}

	return bRet;
}


// IMediaSeeking features
BOOL CDXGraph::GetCurrentPosition(double * dRet)const
{
	if (!m_pMediaSeeking)
		return FALSE;
	
	__int64 position = 0;
	if (SUCCEEDED(m_pMediaSeeking->GetCurrentPosition(&position)))
	{
		*dRet = ((double)position) / 10000000.;
		return TRUE;
	}

	return FALSE;
}

BOOL CDXGraph::GetStopPosition(double * dRet)const
{
	if (m_pMediaSeeking)
	{
		__int64 position = 0;
		if (SUCCEEDED(m_pMediaSeeking->GetStopPosition(&position)))
		{
			*dRet = ((double)position) / 10000000.;
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CDXGraph::SetCurrentPosition(double inPosition)
{
	if (m_pMediaSeeking)
	{
		__int64 one = 10000000;
		__int64 position = (__int64)(one * inPosition);
		HRESULT hr = m_pMediaSeeking->SetPositions(&position, AM_SEEKING_AbsolutePositioning | AM_SEEKING_SeekToKeyFrame, 
			0, AM_SEEKING_NoPositioning);
		return SUCCEEDED(hr);
	}
	return FALSE;
}

BOOL CDXGraph::SetStartStopPosition(double inStart, double inStop)
{
	if (m_pMediaSeeking)
	{
		__int64 one = 10000000;
		__int64 startPos = (__int64)(one * inStart);
		__int64 stopPos = (__int64)(one * inStop);
		HRESULT hr = m_pMediaSeeking->SetPositions(&startPos, AM_SEEKING_AbsolutePositioning | AM_SEEKING_SeekToKeyFrame, 
			&stopPos, AM_SEEKING_AbsolutePositioning | AM_SEEKING_SeekToKeyFrame);
		return SUCCEEDED(hr);
	}
	return FALSE;
}

BOOL CDXGraph::GetDuration(double * dRet)const
{
	if (m_pMediaSeeking)
	{
		__int64 length = 0;
		if (SUCCEEDED(m_pMediaSeeking->GetDuration(&length)))
		{
			*dRet = ((double)length) / 10000000.;
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CDXGraph::SetPlaybackRate(double inRate)
{
	if (m_pMediaSeeking)
	{
		if (SUCCEEDED(m_pMediaSeeking->SetRate(inRate)))
		{
			return TRUE;
		}
	}
	return FALSE;
}

// Attention: range from -10000 to 0, and 0 is FULL_VOLUME.
BOOL CDXGraph::SetAudioVolume(long inVolume)
{
	if (m_pBasicAudio)
	{
		HRESULT hr = m_pBasicAudio->put_Volume(inVolume);
		return SUCCEEDED(hr);
	}
	return FALSE;
}

long CDXGraph::GetAudioVolume()const
{
	long volume = 0;
	if (m_pBasicAudio)
	{
		m_pBasicAudio->get_Volume(&volume);
	}
	return volume;
}

// Attention: range from -10000(left) to 10000(right), and 0 is both.
BOOL CDXGraph::SetAudioBalance(long inBalance)
{
	if (m_pBasicAudio)
	{
		HRESULT hr = m_pBasicAudio->put_Balance(inBalance);
		return SUCCEEDED(hr);
	}
	return FALSE;
}

long CDXGraph::GetAudioBalance()const
{
	long balance = 0;
	if (m_pBasicAudio)
	{
		m_pBasicAudio->get_Balance(&balance);
	}
	return balance;
}

//-----------------------------------------------------------------------------
// Msg: Display an error message box if needed
//-----------------------------------------------------------------------------
void CDXGraph::Msg(TCHAR *szFormat, ...)
{
	TCHAR szBuffer[1024];  // Large buffer for long filenames or URLs
	const size_t NUMCHARS = sizeof(szBuffer) / sizeof(szBuffer[0]);
	const int LASTCHAR = NUMCHARS - 1;

	// Format the input string
	va_list pArgs;
	va_start(pArgs, szFormat);

	// Use a bounded buffer size to prevent buffer overruns.  Limit count to
	// character size minus one to allow for a NULL terminating character.
	_vsntprintf(szBuffer, NUMCHARS - 1, szFormat, pArgs);
	va_end(pArgs);

	// Ensure that the formatted string is NULL-terminated
	szBuffer[LASTCHAR] = TEXT('\0');

	MessageBox(NULL, szBuffer, TEXT("DirectShow Texture3D Sample"), 
		MB_OK | MB_ICONERROR);
}


//HRESULT CDXGraph::DoRenderSample(IMediaSample *pMediaSample, LONG lVidWidth, LONG lVidHeight)
//{
//	return S_OK;
//}



