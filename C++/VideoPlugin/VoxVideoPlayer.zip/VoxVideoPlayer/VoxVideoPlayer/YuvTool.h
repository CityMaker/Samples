#pragma once

class YuvTool
{
public:
    YuvTool();
    ~YuvTool();
    void ConvertYUVtoRGB (unsigned char *src0, unsigned char *src1, unsigned char *src2,
        unsigned char *dst_ori,int width,int height);

private:
    void init_dither_tab();

private:
    //����YUV->RGBת���ĺ���
    unsigned char *clp;
    unsigned char *clp1;
    long int crv_tab[256];
    long int cbu_tab[256];
    long int cgu_tab[256];

    long int cgv_tab[256];
    long int tab_76309[256];
};
