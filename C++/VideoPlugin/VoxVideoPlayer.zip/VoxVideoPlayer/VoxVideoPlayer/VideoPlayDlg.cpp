// VideoPlayDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "VoxVideoPlayer.h"
#include "VoxVideoPlayerApp.h"
#include "VideoPlayDlg.h"


YuvTool yuvTool;
extern long __voxInstance;


// CVideoPlayDlg �Ի���

IMPLEMENT_DYNAMIC(CVideoPlayDlg, CDialog) 

CVideoPlayDlg::CVideoPlayDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVideoPlayDlg::IDD, pParent)
	, m_bmpBuffer(NULL)
{

}

CVideoPlayDlg::~CVideoPlayDlg()
{
	log(L"Enter CVideoPlayDlg::~CVideoPlayDlg");

	if(m_bmpBuffer)
	{
		delete m_bmpBuffer;
		m_bmpBuffer = NULL;
	}
}

void CVideoPlayDlg::StopPlay()
{
	log(L"Enter CVideoPlayDlg::StopPlay");

	log(L"start VOX_CVSA_CloseYUVCapture");
	VOX_CVSA_CloseYUVCapture(__voxInstance, m_lRealHandle);
	log(L"end VOX_CVSA_CloseYUVCapture");

	log(L"start VOX_CVSA_ClosePlayWnd");
	VOX_CVSA_ClosePlayWnd(__voxInstance, m_lRealHandle);
	log(L"end VOX_CVSA_ClosePlayWnd");
}

void CVideoPlayDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_STATIC_VIDEOWND, m_videoWnd);
}


BEGIN_MESSAGE_MAP(CVideoPlayDlg, CDialog)
    ON_WM_TIMER()
	ON_WM_DESTROY()
END_MESSAGE_MAP()


// CVideoPlayDlg ��Ϣ��������

BOOL CVideoPlayDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    SetWindowText(m_uri.c_str());

    VOX_CVSA_ClosePlayWnd(__voxInstance, m_lRealHandle);
    long hr =VOX_CVSA_OpenLivePlay(__voxInstance, m_camNo, 0, 0, 1, 0, &m_lRealHandle, (ULONG)m_videoWnd.m_hWnd); 
    if(0!=hr)
    {
        CString str;
        str.Format(L"����Ƶʧ��!�����룺0x%08x", hr);
        AfxMessageBox(str);
    }
    else
    {
        VOX_CVSA_MakeIFrame(__voxInstance, m_lRealHandle);        
        VOX_CVSA_OpenYUVCapture(__voxInstance, m_lRealHandle, CVideoPlayDlg::OnDealYUVFrame, (long)this);
    }

#ifdef _ONLY_FOR_TEST
	srand( (unsigned)time( NULL ) ); 
    SetTimer(1, 40, NULL);
#endif

    return TRUE;  // return TRUE unless you set the focus to a control
    // �쳣: OCX ����ҳӦ���� FALSE
}


void CVideoPlayDlg::SetParam(const std::wstring& uri, int camNo, const RenderSampleCallback& cb)
{
    m_uri = uri;
    m_camNo = camNo;
    m_callback = cb;
}

void _stdcall CVideoPlayDlg::OnDealYUVFrame(long lStreamID,int frameType, unsigned char * YData, int YLineSize, unsigned char * UData, int ULineSize, unsigned char * VData, int VLineSize, int width, int height,long lUserData)
{
    CVideoPlayDlg* pThis = (CVideoPlayDlg*)lUserData;
   
    CString strText;
	strText.Format(L"ID:%d,Y:%d,U:%d,V:%d,W:%d,H:%d", lStreamID, YLineSize, ULineSize, VLineSize, width, height);
    pThis->SetDlgItemText(IDC_STATIC_INFO, strText);

	if(pThis->m_bmpBuffer == NULL)
	{
		pThis->m_bmpBuffer=new unsigned char[width*height*3];
	}
	yuvTool.ConvertYUVtoRGB(YData, UData, VData, pThis->m_bmpBuffer, width, height);
	pThis->m_callback(pThis->m_bmpBuffer, width, height);
}

void CVideoPlayDlg::OnTimer(UINT_PTR nIDEvent)
{
    if(m_callback)
    {
        int w = 400;
        int h = 350;
        unsigned char* p = new unsigned char[w*h*3];
        int rndVal = rand() % 200;
        memset(p, rndVal, w*h*3);

        CString strText;
        strText.Format(L"%d", rndVal);
        SetDlgItemText(IDC_STATIC_INFO, strText);

        m_callback(p, 256, 256);
        free(p);
    }


    CDialog::OnTimer(nIDEvent);
}

void CVideoPlayDlg::OnDestroy()
{
#ifdef _ONLY_FOR_TEST
	KillTimer(1);
#endif
	CDialog::OnDestroy();
}
