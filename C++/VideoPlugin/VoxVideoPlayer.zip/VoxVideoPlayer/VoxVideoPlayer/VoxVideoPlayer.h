#pragma once
#include "VideoPlayer/IVideoPlayer.h"
#include "VideoPlayDlg.h"


class VoxVideoPlayer : public IVideoPlayer
{
public:
    VoxVideoPlayer(const std::wstring& uri, int camNo, bool bShowWindow);
    ~VoxVideoPlayer();

    virtual void SetRenderSampleCallback(const RenderSampleCallback& cb); 

    virtual bool Run();
    virtual bool Stop();
    virtual bool Pause();
    virtual bool IsRunning(); 
    virtual bool IsStopped();
    virtual bool IsPaused();
    virtual bool IsComplete();

    virtual bool GetCurrentPosition(double * dRet);
    virtual bool GetStopPosition(double * dRet);
    virtual bool SetCurrentPosition(double inPosition);
    virtual bool SetStartStopPosition(double inStart, double inStop);
    virtual bool GetDuration(double * dRet);
    virtual bool SetPlaybackRate(double inRate);


private:
    std::wstring m_uri;
    int m_camNo;
    CVideoPlayDlg m_dlg;
	bool m_bShowWindow;
};