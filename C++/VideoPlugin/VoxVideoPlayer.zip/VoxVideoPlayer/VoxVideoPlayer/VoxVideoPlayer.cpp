#include "StdAfx.h"
#include "VoxVideoPlayer.h"
#include "VoxVideoPlayerApp.h"
#include <vector>


int __voxVideoPlayerCount = 0;
long __voxInstance = -1;


VoxVideoPlayer::VoxVideoPlayer(const std::wstring& uri, int camNo, bool bShowWindow)
: m_uri(uri)
, m_camNo(camNo)
, m_bShowWindow(bShowWindow)
{
	log(L"Enter VoxVideoPlayer::VoxVideoPlayer");
	++ __voxVideoPlayerCount;	

	CString str;
	str.Format(L"__voxVideoPlayerCount: %d", __voxVideoPlayerCount);
	log(str);
}

VoxVideoPlayer::~VoxVideoPlayer()
{
	log(L"Enter VoxVideoPlayer::~VoxVideoPlayer");


	log(L"start AfxGetStaticModuleState");
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	log(L"end AfxGetStaticModuleState");

	m_dlg.StopPlay();

	log(L"start m_dlg.DestroyWindow");
	m_dlg.DestroyWindow();
	log(L"end m_dlg.DestroyWindow");


	-- __voxVideoPlayerCount;
	if(__voxVideoPlayerCount == 0)
	{
		log(L"!!!__voxVideoPlayerCount == 0");
		//log(L"start VOX_CVSA_Logout");
		//VOX_CVSA_Logout(__voxInstance);
		//log(L"end VOX_CVSA_Logout");

		//log(L"start VOX_CVSA_Cleanup");
		//VOX_CVSA_Cleanup();
		//log(L"end VOX_CVSA_Cleanup");
	}
}


void VoxVideoPlayer::SetRenderSampleCallback(const RenderSampleCallback& cb)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());

	CString str;
	str.Format(L"SetRenderSampleCallback, url:%ls, camNo:%d", m_uri.c_str(), m_camNo);
	log(str);

    m_dlg.SetParam(m_uri, m_camNo, cb);
    m_dlg.Create(CVideoPlayDlg::IDD);
	m_dlg.ShowWindow(m_bShowWindow?SW_SHOW:SW_HIDE);
    m_dlg.UpdateWindow();
}

bool VoxVideoPlayer::Run()
{
    return false;
}


bool VoxVideoPlayer::Stop()
{
    return false;
}


bool VoxVideoPlayer::Pause()
{
    return false;
}


bool VoxVideoPlayer::IsRunning()
{
    return false;
}


bool VoxVideoPlayer::IsStopped()
{
    return false;
}


bool VoxVideoPlayer::IsPaused()
{
    return false;
}


bool VoxVideoPlayer::IsComplete()
{
    return false;
}



bool VoxVideoPlayer::GetCurrentPosition(double * dRet)
{
    *dRet = 0;
    return false;
}


bool VoxVideoPlayer::GetStopPosition(double * dRet)
{
    return false;
}


bool VoxVideoPlayer::SetCurrentPosition(double inPosition)
{

    return false;
}


bool VoxVideoPlayer::SetStartStopPosition(double inStart, double inStop)
{
    return false;
}


bool VoxVideoPlayer::GetDuration(double * dRet)
{
    *dRet = 1;
    return false;
}


bool VoxVideoPlayer::SetPlaybackRate(double inRate)
{
    return false;
}

//
////�����û�������Ϣ֪ͨ
//long VoxVideoPlayer::OnChatNotify(const char *sUserName, const char * sMsg, enum CVSA_MSG_TYPE nMsgType, 
//									  const char * sSrvTime, long lParam)
//{
//	CVoxVideoPlayerApp* pThis = (CVoxVideoPlayerApp*)lParam;
//	if(pThis == NULL) 
//		return 0;
//
//	log(L"fun:%s,sub:%s, body:%s", sUserName, sMsg, sSrvTime);
//
//
//	return 0;
//}
//
//
////��Ƶ�л�����ϱ�
//long VoxVideoPlayer::OnReportSwitchVideoResult(int nMonNo,int nCamNo,long result,const char *errInfo, long lParam)
//{
//	USES_CONVERSION;
//	CVoxVideoPlayerApp* pThis = (CVoxVideoPlayerApp*)lParam;
//	if(pThis == NULL) return 0;
//
//	if(result == 0){
//		log(L"�л�����ص����л���Ƶ%d��������%d�ɹ�!", nCamNo, nMonNo);
//	}else{
//		GFX_LOG_ERROR(VoxVideoPlayer2, L"�л�����ص����л���Ƶ%d��������%dʧ��!��������:%s", nCamNo, nMonNo, A2W(errInfo));
//	}
//	return 0;
//}
//
////��ع�ϵ�ϱ�
//long VoxVideoPlayer::OnReportVideoMapping(int nMonNo,int nCamNo, long lParam)
//{
//	CVoxVideoPlayerApp* pThis = (CVoxVideoPlayerApp*)lParam;
//	if(pThis == NULL) 
//		return 0;
//
//	log(L"ӳ���ϵ�ı�ص���������%d�������%d��Ӧ��ϵ�ı�!", nMonNo, nCamNo);
//	return 0;
//}	
////��Ƶ״̬�ϱ�
//long VoxVideoPlayer::OnReportVideoInStatus(int nCamNo, struct CVSA_VIDEO_STATUS nVideoStatus,
//											   enum CVSA_VIDEO_STATUS_MASK nBitMark, long lParam)
//{
//	USES_CONVERSION;
//	CVoxVideoPlayerApp* pThis = (CVoxVideoPlayerApp*)lParam;
//	if(pThis == NULL) return 0;
//
//	CString str;
//	if(nBitMark == CVSA_DEV_ONLINE_MASK){		
//		str.Format(L"�����%d%s", nCamNo, nVideoStatus.online==0?L"����":L"����");
//	}else if(nBitMark == CVSA_PTZ_LOCK_MASK){		
//		//str.Format("��Ƶ%dPTZ������", nCamNo);	
//	}
//	log(L"%s", str);
//	return 0;
//}
////��Ƶ״̬�ϱ�
//long VoxVideoPlayer::OnReportRouteStatus(int nMonNo, int bLock, long lParam)
//{
//	CVoxVideoPlayerApp* pThis = (CVoxVideoPlayerApp*)lParam;
//	if(pThis == NULL) 
//		return 0;
//
//	CString str;	
//	str.Format(L"������%d·�ɱ�%s", nMonNo, bLock==0?L"����":L"����");
//
//	log(L"%s", str);
//	return 0;
//}
////������״̬�ϱ�
//long VoxVideoPlayer::OnServerStatus(int bOnline, long lParam)
//{
//	CVoxVideoPlayerApp* pThis = (CVoxVideoPlayerApp*)lParam;
//	if(pThis == NULL) return 0;
//	if(bOnline){
//		log(L"����������!");
//	}else{
//		log(L"����������!");
//	}
//	return 0;
//}
////���������û�״̬�ϱ�
//long VoxVideoPlayer::OnUserStatus(int bOnline,const char *sUserName, long lParam)
//{
//	CVoxVideoPlayerApp* pThis = (CVoxVideoPlayerApp*)lParam;
//	if(pThis == NULL) 
//		return 0;
//
//	CString str;
//	str.Format(L"�û�\"%s\"%s", sUserName, bOnline == 0?L"����":L"����");
//	log(L"%s", str);
//	return 0;
//}
////·��ѡ��
//long VoxVideoPlayer::OnRotueSelect(struct CVSA_ROUTE_INFO *pRoute, long lParam)
//{
//	CVoxVideoPlayerApp* pThis = (CVoxVideoPlayerApp*)lParam;
//	if(pThis == NULL) 
//		return 0;
//
//	return 0;
//}




void Tokenize(const std::string& str,  
              std::vector<std::string>& tokens,  
              const std::string& delimiters)  
{  
    tokens.clear();
    // Skip delimiters at beginning.  
    std::string::size_type lastPos = str.find_first_not_of(delimiters, 0);  
    // Find first "non-delimiter".  
    std::string::size_type pos     = str.find_first_of(delimiters, lastPos);  
    while (std::string::npos != pos || std::string::npos != lastPos)  
    {  
        // Found a token, add it to the vector.  
        tokens.push_back(str.substr(lastPos, pos - lastPos));  
        // Skip delimiters.  Note the "not_of"  
        lastPos = str.find_first_not_of(delimiters, pos);  
        // Find next "non-delimiter"  
        pos = str.find_first_of(delimiters, lastPos);  
    }  
}  

bool VoxInit()
{
	if(__voxInstance != -1)
		return true;

	log(L"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	log(L"VOX_CVSA_Startup!");

	long hr = VOX_CVSA_Startup();
	if(0 == hr)
	{
		hr = VOX_CVSA_CreateInstance(&__voxInstance, 0);
		if(hr==0)
		{
			//CVSA_NOTIFY cvsaNotify;
			//cvsaNotify.lOnChatNotifyParam = (long)this;
			//cvsaNotify.lOnReportSwitchVideoResultParam = (long)this;
			//cvsaNotify.lOnReportVideoInStatusParam = (long)this;
			//cvsaNotify.lOnReportVideoMappingParam = (long)this;
			//cvsaNotify.lOnReportRouteStatus = (long)this;
			//cvsaNotify.lOnRotueSelectParam = (long)this; 
			//cvsaNotify.lOnServerStatusParam = (long)this;
			//cvsaNotify.lOnUserStatusParam = (long)this;
			//cvsaNotify.OnChatNotify = OnChatNotify;
			//cvsaNotify.OnReportSwitchVideoResult = OnReportSwitchVideoResult;
			//cvsaNotify.OnReportVideoInStatus = OnReportVideoInStatus;
			//cvsaNotify.OnReportVideoMapping = OnReportVideoMapping;
			//cvsaNotify.OnReportRouteStatus = OnReportRouteStatus;
			//cvsaNotify.OnRotueSelect = NULL;
			//cvsaNotify.OnServerStatus = OnServerStatus;
			//cvsaNotify.OnUserStatus = OnUserStatus;
			//VOX_CVSA_SetNotify(__voxInstance, &cvsaNotify);
		}
		else
		{
			CString str;
			str.Format(_T("����ʵ��ʧ��, ʧ��ԭ��:0x%08x"), hr);
			AfxMessageBox(str);
			return false;
		}
	}
	else
	{
		CString str;
		str.Format(_T("����ʧ��, ʧ��ԭ��:0x%08x"), hr);
		AfxMessageBox(str);
		return false;
	}

	//��ʾ�汾��Ϣ
	char sCVSAVer[100], sCVSABuild[100];
	VOX_CVSA_GetVersion(sCVSAVer, sCVSABuild);    
	
	USES_CONVERSION;
	CString str;
	str.Format(L"CVSA(V%s.B%s)", A2W(sCVSAVer), A2W(sCVSABuild));
	log(str);

	return true;
}


/************************************************************************/
/* �ַ�����ʽ��
    vp://vorx/192.168.5.250:5051:1001/vorx/vorx/1
/************************************************************************/
extern "C" VIDEOPLAYER_API IVideoPlayer* VideoPlayerDllStartup(const std::wstring& uri)
{
    USES_CONVERSION;
    AFX_MANAGE_STATE(AfxGetStaticModuleState());
    IVideoPlayer* r = NULL;

#ifdef _ONLY_FOR_TEST
	// only for test
	std::wstring uri2 = L"vp://vorx/192.168.5.250:5051:1001/vorx/vorx/1";
	r = new VoxVideoPlayer(uri2, 1000, true);

#else
	CString str;
	str.Format(L"VideoPlayerDllStartup: %ls", uri.c_str());
	log(str);

	bool isValidURI = false;
	std::string strIP;
	int nPort;
	int camNo;
	std::string strUser;
	std::string strPass;
	bool bShowWindow = false;

	int n = uri.find(L"vp://vorx/");
	if(n != -1)
	{
		std::string auri = W2A(uri.c_str());
		std::string ss = auri.substr(10);

		std::vector<std::string> vs;
		Tokenize(ss, vs, "/");

		if(vs.size() >= 3)
		{
			std::string strHost = vs[0];
			strUser = vs[1];
			strPass = vs[2];
			if(vs.size() == 4)
				bShowWindow = !!atoi(vs[3].c_str());

			Tokenize(strHost, vs, ":");
			if(vs.size() >= 3)
			{
				strIP = vs[0];
				nPort = atoi(vs[1].c_str());
				camNo = atoi(vs[2].c_str());
				isValidURI = true;
			}
			else
			{
				str.Format(L"error uri format: %s", uri.c_str());
				log(str);
			}
		}
		else
		{
			str.Format(L"error uri format: %s", uri.c_str());
			log(str);
		}
	}
	else
	{
		str.Format(L"not support uri: %s", uri.c_str());
		log(str);
	}

	if(isValidURI)
	{
		if(__voxInstance == -1)
			VoxInit();
		
		long hr = VOX_CVSA_Login(__voxInstance, strIP.c_str(), nPort, strUser.c_str(), strPass.c_str(), 1);
		if(0 == hr)
		{
			log(L"Login OK!");
		}
		else
		{
			char buff[100];
			int ret = VOX_CVSA_GetErrorInfo(__voxInstance, hr, buff, 100);
			str.Format(L"Login failed! code: 0x%08x, Reason: %ls", hr, ret==0? A2W(buff) : L"not found");
			log(str);
		}
		r = new VoxVideoPlayer(uri, camNo, bShowWindow);
	}
#endif

    return r;
}


