#pragma once
#include "resource.h"
#include "YuvTool.h"


// CVideoPlayDlg �Ի���

class CVideoPlayDlg : public CDialog
{
    DECLARE_DYNAMIC(CVideoPlayDlg)
    DECLARE_MESSAGE_MAP()

public:
    CVideoPlayDlg(CWnd* pParent = NULL);   // ��׼���캯��
    virtual ~CVideoPlayDlg();

	void StopPlay();

    // �Ի�������
    enum { IDD = IDD_DIALOG_VIDEO };
    CStatic m_videoWnd;
	unsigned char* m_bmpBuffer;
	RenderSampleCallback m_callback;

    //YUV����
    static void _stdcall OnDealYUVFrame(long lStreamID,int frameType, unsigned char * YData, int YLineSize, unsigned char * UData, int ULineSize, unsigned char * VData, int VLineSize, int width, int height,long lUserData);

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
    virtual BOOL OnInitDialog();

private:
    int m_camNo;   
    std::wstring m_uri;
    long m_lRealHandle;


public:
    void SetParam(const std::wstring& uri, int camNo, const RenderSampleCallback& cb);
    afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnDestroy();
};
