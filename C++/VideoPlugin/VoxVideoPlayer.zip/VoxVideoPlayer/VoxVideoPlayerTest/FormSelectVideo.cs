﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TerrainVideo
{
    public partial class FormSelectVideo : Form
    {
        public FormSelectVideo()
        {
            InitializeComponent();
        }

        public string GetVideoName()
        {
            return this.textBox1.Text;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

   
    }
}
